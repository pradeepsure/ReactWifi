import React from 'react';
import CustomerService from './customerService'
class Comp3 extends React.Component{
    constructor(){
        super();
        this.state={
            overheat: '',
            restart:'',
            reset:'',
            hardware:'',
            frirmware:'',
            overheatingSolution:'',
            restartSolution:'',
            resetSolution:'',
            hardwareSolution:'',
            frirmwareSolution:'',
            solved:'',
            overheatingSol: false,
            restartSol: false,
            resetSol: false,
            hardwareSol:false,
            frirmwareSol:false,
            showMsg:false,
            isIssueResolved:'',
            isSubmitted:false
        }
        // this.updateData_Power=this.updateData_Power.bind(this);
        //this.updateData_Wires=this.updateData_Wires.bind(this);
        // this.updateData_Cycling=this.updateData_Cycling.bind(this);
        // this.updateData_Connections=this.updateData_Connections.bind(this);
        // this.updateData_Outages=this.updateData_Outages.bind(this);
        //this.clearData=this.clearData.bind(this);
    }
    updateData_Power = (e) => {    
        this.setState(
            {
                overheat : e.target.value
            }
        )     
    }
    updateData_Wires = (e) => {
        this.setState(
            {
                restart : e.target.value
            }
        )
    }
    updateData_Cycling=(e)=>{
        this.setState(
            {
                reset : e.target.value
            }
        )
    }
    updateData_Connections=(e)=>{
        this.setState(
            {
                hardware : e.target.value
            }
        )
    }
    updateData_Outages=(e)=>{
        this.setState(
            {
                frirmware : e.target.value
            }
        )
    }
    handleSubmit = (event) => {
         event.preventDefault();
         const {overheatingSol, restartSol, resetSol, hardwareSol, frirmwareSol} = this.state;
        
        this.setState({
            isSubmitted:true
        })
        if(this.state.overheat === 'UN_Checked') {  
            this.setState(prevState => ({overheatingSol:true, overheatingSolution : 'Your WiFi router can’t work properly if it overheats. Just try placing it at a cooler place or using a fan to cool it down.' }))
        }
        else {
             this.setState(prevState => ({overheatingSol:true, overheatingSolution : 'great!! Your router is no overheats' }))
        }
        if(this.state.restart === 'NO'){
          
            this.setState(prevState => ({restartSol:!prevState.restartSol, restartSolution : 'This can reset your Internet connection and fix your WiFi issue. To restart your router' }))
        }
        else{
                this.setState(prevState => ({restartSol:!prevState.restartSol, restartSolution : 'great work!! will see further more steps!!' }))
        }
        if(this.state.reset === 'NO'){
          
            this.setState(prevState => ({resetSol:!prevState.resetSol, resetSolution : 'Perhaps there are wrong settings on your router so you can’t use its wireless feature. To fix this issue, you should reset your router'}))
        }
        else{
            this.setState(prevState => ({resetSol:!prevState.resetSol, resetSolution : 'your Router settings resetted properly...' }))
        }
        if(this.state.hardware === 'NO') {
           
            this.setState(prevState => ({hardwareSol:!prevState.hardwareSol, hardwareSolution : 'If your WiFi router is still not working, it’s likely that there are hardware issues with your devices or cable.' }))
        }
        else{
           
            this.setState(prevState => ({hardwareSol:!prevState.hardwareSol, hardwareSolution : 'your hardware is fine' }))
        }
        if(this.state.frirmware === 'NOT_UPDATED') {
           
            this.setState(prevState => ({frirmwareSol:!prevState.frirmwareSol, frirmwareSolution : 'The manufacturer of your router releases regular firmware updates to fix security issues. You should make sure your router firmware is up to date.' }))
        }
        else{
            this.setState(prevState => ({frirmwareSol:!prevState.frirmwareSol, frirmwareSolution : 'Your ROUTER is up to date!!!' }))
        }
    }
    handleIssue = (e) => {
         this.setState({isIssueResolved: e.target.value.toUpperCase()})
    }
    // handleIssueSelection = () => {
    //     if(this.state.isIssueResolved === 'NO'){
    //         this.setState(prevState => ({showMsg:!prevState.showMsg }))
               
    //     }
    // }
    solvedOrNot=(e)=>{

    }
    render(){
        console.log('this.state.resetSol',this.state.resetSol);
        return(
            <div style={{border:'2px solid black', margin:'10px', padding:'10px'}}>
                <h1>Provide answers for below questions</h1>
                <form  onSubmit={this.handleSubmit}>
                    
                    <h3 style={{ padding:'10px'}}>Select your answers</h3>
                    <div >
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check for overheating issue for your router</span> 
                        <select value={this.state.overheat} onChange={this.updateData_Power} >
                         <option>Select</option>
                        <option>Checked</option>
                        <option>UN_Checked</option>
                        </select><br/><br/>
                        </label> 
                    </div>
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Restart your router</span>
                        <select value={this.state.restart} onChange={this.updateData_Wires} >
                        <option>Select</option>
                        <option>YES</option>
                        <option>NO</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div >
                        <label><span style={{padding:'25px', fontWeight:"bold"}}>Reset your router</span>
                        <select value={this.state.reset} onChange={this.updateData_Cycling} >
                        <option>Select</option>
                        <option>YES</option>
                        <option>NO</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Troubleshoot hardware issues</span>
                        <select value={this.state.hardware} onChange={this.updateData_Connections}>
                        <option>Select</option>
                        <option>YES</option>
                        <option>NO</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px' , fontWeight:"bold"}}>Update your router firmware</span>
                        <select value={this.state.frirmware} onChange={this.updateData_Outages}>
                        <option>Select</option>
                        <option>UPDATED</option>
                        <option>NOT_UPDATED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    </div>
                    <button className="btn btn-success">Submit</button>
                    
                    
                </form>
                        {this.state.overheatingSol &&   <div> 
                            <h3> {this.state.overheatingSolution} </h3> 
                        </div>}
                        {this.state.restartSol &&   <div>
                           <h3>{this.state.restartSolution}</h3>
                        </div>}
                        {this.state.resetSol &&   <div> 
                            <h3>{this.state.resetSolution}</h3>
                        </div>}
                        {this.state.hardwareSol &&   <div> 
                            <h3>{this.state.hardwareSolution}</h3>
                        </div>}
                        {this.state.frirmwareSol &&   <div> 
                            <h3>{this.state.frirmwareSolution}</h3>
                        </div>}
                        
               {this.state.isSubmitted &&         <div>
                            Is Your issue resolved:<select value={this.state.isIssueResolved} onChange={this.handleIssue}>
                            <option>Select</option>
                            <option>Yes</option>
                            <option>NO</option>
                            </select><br/><br/>
                            <div style={{margin:'10px'}}>
                                {this.state.isIssueResolved === 'YES' ?'Thank you!!':''}
                                {this.state.isIssueResolved === 'NO' ?<CustomerService/>:''}
                            </div>
               </div>}

            </div>
        );
    }
}
export default Comp3;