import React, { Fragment } from 'react';
import ImgUrl from '../images/wifi_issue.jfif';

const WelcomePage = () => (
    <Fragment>
        <div align='center'>
            <h2 style={{ color: 'green' }}>
                Welcome to Wi-Fi Issues and solve your problems easy way!!!.
            </h2>          
        </div>
        <img src={ImgUrl} alt="Wi-Fi App"  height="100%" width="100%"/>
    </Fragment>
);
export default WelcomePage;