import React from 'react';

class WifiProblems extends React.Component {
    constructor() {
        super();
        this.state ={
            powerStatus:'',
            solution:''
        }
    }
        handleChange = (e) => {
            this.setState({
                powerStatus : e.target.value
            })
        }
        handleSubmit = () => {
             this.setState({
                solution : 'please power ON'
            })
        }
    
    render() {
        return(
            <div>
          
            Power:
            <input type="text"  value = {this.state.powerStatus} onChange={this.handleChange}/><br/><br/>
            
           <button onClick={this.handleSubmit}>Solution</button><br/><br/>
            Solution:{this.state.powerStatus === 'ON'?'':this.state.solution}
            </div>
        )
    }
}

export default WifiProblems;