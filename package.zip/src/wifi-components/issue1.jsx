import React from 'react';
//import axios from 'axios';
import Comp2 from './issue2'
import CustomerService from './customerService'
class Comp1 extends React.Component{
    constructor(){
        super();
        this.state={
            powerCycle: '',
            physicalConnection:'',
            networkTroubleshooter:'',
            valid_IP_Address:'',
            ping:'',
            powerCycleSolution:'',
            physicalConnectionSolution:'',
            networkTroubleshooterSolution:'',
            valid_IP_Address_Solution:'',
            pingSolution:'',
            solved:'',
            powerCycleSol: false,
            physicalConnectionSol: false,
            networkTroubleshooterSol: false,
            valid_IP_Address_Sol:false,
            pingSol:false,
            showMsg:false,
            isIssueResolved:'',
            isSubmitted:false
        }
        // this.updateData_Power=this.updateData_Power.bind(this);
        //this.updateData_Wires=this.updateData_Wires.bind(this);
        // this.updateData_Cycling=this.updateData_Cycling.bind(this);
        // this.updateData_Connections=this.updateData_Connections.bind(this);
        // this.updateData_Outages=this.updateData_Outages.bind(this);
        //this.clearData=this.clearData.bind(this);
    }
    updateData_Power = (e) => {    
        this.setState(
            {
                powerCycle : e.target.value
            }
        )     
    }
    updateData_Wires = (e) => {
        this.setState(
            {
                physicalConnection : e.target.value
            }
        )
    }
    updateData_Cycling=(e)=>{
        this.setState(
            {
                networkTroubleshooter : e.target.value
            }
        )
    }
    updateData_Connections=(e)=>{
        this.setState(
            {
                valid_IP_Address : e.target.value
            }
        )
    }
    updateData_Outages=(e)=>{
        this.setState(
            {
                ping : e.target.value
            }
        )
    }
    handleSubmit = (event) => {
         event.preventDefault();
         const {powerCycleSol, physicalConnectionSol, networkTroubleshooterSol, valid_IP_Address_Sol, pingSol} = this.state;
        
        this.setState({
            isSubmitted:true
        })
        if(this.state.powerCycle === 'NOT_CHECKED') {  
            this.setState(prevState => ({powerCycleSol:true, powerCycleSolution : 'There’s no need to get upset right away, as the fix to your problem might be as simple as rebooting your equipment' }))
        }
        else  {
             this.setState(prevState => ({powerCycleSol:true, powerCycleSolution : 'Your powerCycle Connections are good' }))
        }
        
        if(this.state.physicalConnection === 'NOT_CHECKED'){   
            this.setState(prevState => ({physicalConnectionSol:!prevState.physicalConnectionSol, physicalConnectionSolution : 'Does your network problem persist after rebooting? Before you start diving into settings and tests, the next step to check is that you’re physically connected.' }))
        }
        else{
                this.setState(prevState => ({physicalConnectionSol:!prevState.physicalConnectionSol, physicalConnectionSolution : 'Your wireless physicalConnections are proper' }))
        }
        if(this.state.networkTroubleshooter === 'NO'){
          
            this.setState(prevState => ({networkTroubleshooterSol:!prevState.networkTroubleshooterSol, networkTroubleshooterSolution : 'Windows includes some built-in troubleshooters that can automatically find and fix issues. ' }))
        }
        else{
            this.setState(prevState => ({networkTroubleshooterSol:!prevState.networkTroubleshooterSol, networkTroubleshooterSolution : 'great!!' }))
        }
        if(this.state.valid_IP_Address === 'NOT_VERIFIED') {
           
            this.setState(prevState => ({valid_IP_Address_Sol:!prevState.valid_IP_Address_Sol, valid_IP_Address_Solution : 'At this point, you’ve verified that the problem is not temporary and that all your hardware works.' }))
        }
        else{
           
            this.setState(prevState => ({valid_IP_Address_Sol:!prevState.valid_IP_Address_Sol, valid_IP_Address_Solution : 'Your IP address is successfully verified' }))
        }
        if(this.state.ping === 'NOT_VERIFIED') {
           
            this.setState(prevState => ({pingSol:!prevState.pingSol, pingSolution : 'If your IP address starts with anything other than 169 when you run ipconfig, you have a valid IP address from your router.' }))
        }
        else{
            this.setState(prevState => ({pingSol:!prevState.pingSol, pingSolution : 'great!!' }))
        }
    }
    handleIssue = (e) => {
         this.setState({isIssueResolved: e.target.value.toUpperCase()})
    }
    // handleIssueSelection = () => {
    //     if(this.state.isIssueResolved === 'NO'){
    //         this.setState(prevState => ({showMsg:!prevState.showMsg }))
               
    //     }
    // }
    solvedOrNot=(e)=>{

    }
    render(){
        console.log('this.state.networkTroubleshooterSol',this.state.networkTroubleshooterSol);
        return(
            <div style={{border:'2px solid black', margin:'10px', padding:'10px'}}>
                <h1>Provide answers for below questions</h1>
                <form  onSubmit={this.handleSubmit}>
                    
                    <h3 style={{ padding:'10px'}}>Select your answers</h3>
                    <div >
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check Power Cycle Everything and Check Other Devices</span> 
                        <select value={this.state.powerCycle} onChange={this.updateData_Power} >
                         <option>Select</option>
                        <option>CHECKED</option>
                        <option>NOT_CHECKED</option>
                        </select><br/><br/>
                        </label> 
                    </div>
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check Physical Connectionsr</span>
                        <select value={this.state.physicalConnection} onChange={this.updateData_Wires} >
                        <option>Select</option>
                        <option>CHECKED</option>
                        <option>NOT_CHECKED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div >
                        <label><span style={{padding:'25px', fontWeight:"bold"}}>Run the Windows Network Troubleshooter</span>
                        <select value={this.state.networkTroubleshooter} onChange={this.updateData_Cycling} >
                        <option>Select</option>
                        <option>YES</option>
                        <option>NO</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check for a Valid IP Address</span>
                        <select value={this.state.valid_IP_Address} onChange={this.updateData_Connections}>
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px' , fontWeight:"bold"}}>Try a Ping and Trace Its Route</span>
                        <select value={this.state.ping} onChange={this.updateData_Outages}>
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    </div>
                    <button className="btn btn-success">Submit</button>
                    
                    
                </form>
                        {this.state.powerCycleSol &&   <div> 
                            <h3> {this.state.powerCycleSolution} </h3> 
                        </div>}
                        {this.state.physicalConnectionSol &&   <div>
                           <h3>{this.state.physicalConnectionSolution}</h3>
                        </div>}
                        {this.state.networkTroubleshooterSol &&   <div> 
                            <h3>{this.state.networkTroubleshooterSolution}</h3>
                        </div>}
                        {this.state.valid_IP_Address_Sol &&   <div> 
                            <h3>{this.state.valid_IP_Address_Solution}</h3>
                        </div>}
                        {this.state.pingSol &&   <div> 
                            <h3>{this.state.pingSolution}</h3>
                        </div>}
                        
               {this.state.isSubmitted &&         <div>
                            Is Your issue resolved:<select value={this.state.isIssueResolved} onChange={this.handleIssue}>
                            <option>Select</option>
                            <option>Yes</option>
                            <option>NO</option>
                            </select><br/><br/>
                            <div style={{margin:'10px'}}>
                                {this.state.isIssueResolved === 'YES' ?'Thank you!!':''}
                                {this.state.isIssueResolved === 'NO' ?<CustomerService/>:''}
                            </div>
               </div>}

            </div>
        );
    }
}
export default Comp1;