import React, {Component} from 'react'

class FooterComponent extends Component {
    render() {
        return (
            <footer className="footer" style={{
  position: 'fixed',
  left: '0px',
  bottom: '0px',
  width: "100%",
  height: "70px",
  backgroundColor: "black",
  color: "white",
  textAlign: "center",
  border:'1px solid black'
}}>
                <span style={{color:'white', padding:'20px', textAlign: "center",}}>All Rights Reserved 2019 @Pradeep</span>
            </footer>
        )
    }
}

export default FooterComponent