import React from 'react';

class CustomerService extends React.Component{
    render(){
        return(
            <div>
                <h3><span style={{color:'red', marign:'5px'}}>Please Contact our CustomerService Number:</span> 2222-555-669-635</h3>
            </div>
        );
    }
}
export default CustomerService;