import React from 'react';
//import axios from 'axios';
import Comp2 from './issue2'
import CustomerService from './customerService'
class Comp1 extends React.Component{
    constructor(){
        super();
        this.state={
            power: '',
            wires:'',
            cycling:'',
            connections:'',
            outages:'',
            powerSolution:'',
            wireSolution:'',
            cycleSolution:'',
            connectionsSolution:'',
            outagesSolution:'',
            solved:'',
            showPowerSol: false,
            showwiresSol: false,
            showCyclingSol: false,
            showConnections:false,
            showOutages:false,
            showMsg:false,
            isIssueResolved:''
        }
        // this.updateData_Power=this.updateData_Power.bind(this);
        //this.updateData_Wires=this.updateData_Wires.bind(this);
        // this.updateData_Cycling=this.updateData_Cycling.bind(this);
        // this.updateData_Connections=this.updateData_Connections.bind(this);
        // this.updateData_Outages=this.updateData_Outages.bind(this);
        //this.clearData=this.clearData.bind(this);
    }
    updateData_Power = (e) => {    
        this.setState(
            {
                power : e.target.value
            }
        )     
    }
    updateData_Wires = (e) => {
        this.setState(
            {
                wires : e.target.value
            }
        )
    }
    updateData_Cycling=(e)=>{
        this.setState(
            {
                cycling : e.target.value
            }
        )
    }
    updateData_Connections=(e)=>{
        this.setState(
            {
                connections : e.target.value
            }
        )
    }
    updateData_Outages=(e)=>{
        this.setState(
            {
                outages : e.target.value
            }
        )
    }
    handleSubmit = (event) => {
         event.preventDefault();
         const {showPowerSol, showwiresSol, showCyclingSol, showConnections, showOutages} = this.state;
        
        if(this.state.power === 'OFF') {  
            this.setState(prevState => ({showPowerSol:!prevState.showPowerSol, powerSolution : 'ON' }))
        }
        if(this.state.wires === 'Un Plugged'){
          
            this.setState(prevState => ({showwiresSol:!prevState.showwiresSol, wireSolution : 'Plugged' }))
        }
        if(this.state.cycling === 'OFF'){
          
            this.setState(prevState => ({showCyclingSol:!prevState.showCyclingSol, cycleSolution : 'ON' }))
        }
        if(this.state.connections === 'OFF') {
           
            this.setState(prevState => ({showConnections:!prevState.showConnections, connectionsSolution : 'ON' }))
        }
        if(this.state.outages === 'OFF') {
           
            this.setState(prevState => ({showOutages:!prevState.showOutages, outagesSolution : 'ON' }))
        }
    }
    handleIssue = (e) => {
         this.setState({isIssueResolved: e.target.value.toUpperCase()})
    }
    // handleIssueSelection = () => {
    //     if(this.state.isIssueResolved === 'NO'){
    //         this.setState(prevState => ({showMsg:!prevState.showMsg }))
               
    //     }
    // }
    solvedOrNot=(e)=>{

    }
    render(){
        console.log('this.state.showCyclingSol',this.state.showCyclingSol);
        return(
            <div style={{border:'2px solid black', margin:'10px', padding:'10px'}}>
                <h1>Provide answers for below questions</h1>
                <form  onSubmit={this.handleSubmit}>
                    
                    <h3 style={{ padding:'10px'}}>Select your answers</h3>
                    <div >
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Power is on/off  </span> 
                        <select value={this.state.power} onChange={this.updateData_Power} >
                         <option>Select</option>
                        <option>ON</option>
                        <option>OFF</option>
                        </select><br/><br/>
                        </label> 
                    </div>
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check the Wires</span>
                        <select value={this.state.wires} onChange={this.updateData_Wires} >
                        <option>Select</option>
                        <option>Plugged</option>
                        <option>Un Plugged</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div >
                        <label><span style={{padding:'25px', fontWeight:"bold"}}>Power Cycling:</span>
                        <select value={this.state.cycling} onChange={this.updateData_Cycling} >
                        <option>Select</option>
                        <option>ON</option>
                        <option>OFF</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Weathering Storms with Satellite Internet Connections</span>
                        <select value={this.state.connections} onChange={this.updateData_Connections}>
                        <option>Select</option>
                        <option>ON</option>
                        <option>OFF</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px' , fontWeight:"bold"}}>Wireless Router Outages</span>
                        <select value={this.state.outages} onChange={this.updateData_Outages}>
                        <option>Select</option>
                        <option>ON</option>
                        <option>OFF</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    </div>
                    <input type="submit" value="Submit" />
                    
                </form>
                        {this.state.showPowerSol &&   <div> 
                            <h3>Your Power should be {this.state.powerSolution} always!!!</h3> 
                        <div>
                        Is Your issue resolved:<select value={this.state.isIssueResolved} onChange={this.handleIssue}>
                        <option>Select</option>
                        <option>Yes</option>
                        <option>NO</option>
                        </select><br/><br/>
                        <div style={{margin:'10px'}}>
                       
                        {this.state.isIssueResolved === 'YES' ?'Thank you!!':''}
                        {this.state.isIssueResolved === 'NO' ?<CustomerService/>:''}
                        </div>
                        </div>
                        </div>}
                        {this.state.showwiresSol &&   <div>
                           <h3>Your wires should be {this.state.wireSolution} always!!!</h3>
                        </div>}
                        {this.state.showCyclingSol &&   <div> 
                            <h3>Your Cycling should be {this.state.cycleSolution} always!!!</h3>
                        </div>}
                        {this.state.showConnections &&   <div> 
                            <h3>Your Connections should be {this.state.connectionsSolution} always!!!</h3>
                        </div>}
                        {this.state.showOutages &&   <div> 
                            <h3>Your Outages should be {this.state.outagesSolution} always!!!</h3>
                        </div>} 
            </div>
        );
    }
}
export default Comp1;