import React from 'react';

class Comp2 extends React.Component{
    constructor(){
        super();
        this.state={
            power: '',
            wires:'',
            cycling:'',
            connections:'',
            outages:'',
            solution:[]
        }
        this.updateData_Power=this.updateData_Power.bind(this);
        this.updateData_Wires=this.updateData_Wires.bind(this);
        this.updateData_Cycling=this.updateData_Cycling.bind(this);
        this.updateData_Connections=this.updateData_Connections.bind(this);
        this.updateData_Outages=this.updateData_Outages.bind(this);
        //this.clearData=this.clearData.bind(this);
    }
    updateData_Power(e){
        this.setState(
            {
                power : e.target.value
            }
        )
    }
    updateData_Wires(e){
        this.setState(
            {
                wires : e.target.value
            }
        )
    }
    updateData_Cycling(e){
        this.setState(
            {
                cycling : e.target.value
            }
        )
    }
    updateData_Connections(e){
        this.setState(
            {
                connections : e.target.value
            }
        )
    }
    updateData_Outages(e){
        this.setState(
            {
                outages : e.target.value
            }
        )
    }
    handleSubmit = (event) => {
        this.setState({
                solution : ['please power ON']
            })
        event.preventDefault();
    }
    render(){
        return(
            <div>
                <h1>Provide answers below questions</h1>
                <form className="demoForm" onSubmit={this.handleSubmit}>
                    <h2>Fill your answers</h2>
                    <div className="form-group">
                        <label>Issue2 Power is on/off</label>
                        <input type="text" value={this.state.power} onChange={this.updateData_Power}/>
                        <h2>Your Answer is {this.state.power}</h2>
                    </div>
                    <div className="form-group">
                        <label>Check the Wires</label>
                        <input type="text" value={this.state.wires} onChange={this.updateData_Wires}/>
                        <h2>Your Answer is { this.state.wires }</h2>
                    </div>
                    <div className="form-group">
                        <label>Power Cycling</label>
                        <input type="text" value={this.state.cycling} onChange={this.updateData_Cycling}/>
                        <h2>Your Answer is { this.state.cycling }</h2>
                    </div>
                    <div className="form-group">
                        <label>Weathering Storms with Satellite Internet Connections</label>
                        <input type="text" value={this.state.connections} onChange={this.updateData_Connections}/>
                        <h2>Your Answer is { this.state.connections }</h2>
                    </div>
                    <div className="form-group">
                        <label>Wireless Router Outages</label>
                        <input type="text" value={this.state.outages} onChange={this.updateData_Outages}/>
                        <h2>Your Answer is { this.state.outages }</h2>
                    </div>
                    <input type="submit" value="Submit" />
                </form>
                 Solution:{(this.state.power === 'ON'?'':this.state.solution)?(this.state.wires==='ON'?'':this.state.solution):'enjoy'}
            </div>
        );
    }
}
export default Comp2;