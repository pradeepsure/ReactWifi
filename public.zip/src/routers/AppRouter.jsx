import React from 'react';
import Comp1 from '../components/issue1'
import Comp2 from '../components/issue2'
import Comp3 from '../components/issue3'
import WelcomePage from '../components/welcomePage'
import {BrowserRouter as Router, Switch, Link, Route} from 'react-router-dom';
class AppRouter extends React.Component{
    render(){
        return(
            <Router>
                <div >
                    <div style={{border:'2px solid black', margin:'10px',padding:'10px', backgroundColor:'grey'}}>
                        <Link to={'/home'} style={{color:"white",fontSize:'1.25rem', padding:'10px'}}>Home </Link>
                        <Link to={'/issue1'}style={{color:"white",fontSize:'1.25rem', padding:'10px'}}>issue1</Link>
                        <Link to={'/issue2'}style={{color:"white",fontSize:'1.25rem', padding:'10px'}}>issue2</Link>
                        <Link to={'/issue3'}style={{color:"white",fontSize:'1.25rem', padding:'10px'}}>issue3</Link>
                    </div>
                    <Switch>
                        <Route exact path = '/home' component={WelcomePage}/>
                        <Route exact path = '/issue1' component={Comp1}/>
                        <Route exact path = '/issue2' component={Comp2}/>
                        <Route exact path = '/issue3' component={Comp3}/>
                    </Switch>
                </div>
            </Router>
        );
    }
}

export default AppRouter;