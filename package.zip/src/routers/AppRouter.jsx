import React from 'react';
import Comp1 from '../wifi-components/issue1'
import Comp2 from '../wifi-components/issue2'
import Comp3 from '../wifi-components/issue3'
import WelcomePage from '../wifi-components/welcomePage'
import {BrowserRouter as Router, Switch, Link, Route} from 'react-router-dom';
class AppRouter extends React.Component{
    render(){
        return(
            <Router>
                <div>      
                    <Switch>
                        <Route exact path = '/home' component={WelcomePage}/>
                        <Route exact path = '/issue1' component={Comp1}/>
                        <Route exact path = '/issue2' component={Comp2}/>
                        <Route exact path = '/issue3' component={Comp3}/>
                    </Switch>
                </div>
            </Router>
        );
    }
}

export default AppRouter;