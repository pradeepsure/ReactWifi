import React from 'react';
import CustomerService from './customerService'
class Comp2 extends React.Component{
    constructor(){
        super();
        this.state={
            cable: '',
            adapters:'',
            accessPoint:'',
            tcpSetting:'',
            networkPing:'',
            cableConnectionSolution:'',
            adapterSolution:'',
            accessPointSolution:'',
            tcpSettingSolution:'',
            networkPingSolution:'',
            solved:'',
            cableConnectionSol: false,
            adapterSol: false,
            accessPointSol: false,
            tcpSettingSol:false,
            networkPingSol:false,
            showMsg:false,
            isIssueResolved:'',
            isSubmitted:false
        }
        // this.updateData_Power=this.updateData_Power.bind(this);
        //this.updateData_Wires=this.updateData_Wires.bind(this);
        // this.updateData_Cycling=this.updateData_Cycling.bind(this);
        // this.updateData_Connections=this.updateData_Connections.bind(this);
        // this.updateData_Outages=this.updateData_Outages.bind(this);
        //this.clearData=this.clearData.bind(this);
    }
    updateData_Power = (e) => {    
        this.setState(
            {
                cable : e.target.value
            }
        )     
    }
    updateData_Wires = (e) => {
        this.setState(
            {
                adapters : e.target.value
            }
        )
    }
    updateData_Cycling=(e)=>{
        this.setState(
            {
                accessPoint : e.target.value
            }
        )
    }
    updateData_Connections=(e)=>{
        this.setState(
            {
                tcpSetting : e.target.value
            }
        )
    }
    updateData_Outages=(e)=>{
        this.setState(
            {
                networkPing : e.target.value
            }
        )
    }
    handleSubmit = (event) => {
         event.preventDefault();
         const {cableConnectionSol, adapterSol, accessPointSol, tcpSettingSol, networkPingSol} = this.state;
        
        this.setState({
            isSubmitted:true
        })
        if(this.state.cable === 'NOT_CONNECTED') {  
            this.setState(prevState => ({cableConnectionSol:true, cableConnectionSolution : 'Verify that devices at both ends of each Ethernet cable are cableed on and that ports are enabled. For example, your AP may be connected to a wall port that is disabled, or the upstream switch or modem may be off.' }))
        }
        else if('CONNECTED') {
             this.setState(prevState => ({cableConnectionSol:true, cableConnectionSolution : 'Your Cable Connections are good' }))
        }
        else if('Select'){
            this.setState(prevState => ({cableConnectionSol:true, cableConnectionSolution : 'ENJOY' }))
        }
        if(this.state.adapters === 'NOT_VERIFIED'){
          
            this.setState(prevState => ({adapterSol:!prevState.adapterSol, adapterSolution : 'It might seem obvious, but its important to ensure the clients Wi-Fi adapter used for network troubleshooting is enabled and ready to connect.' }))
        }
        else{
                this.setState(prevState => ({adapterSol:!prevState.adapterSol, adapterSolution : 'Your wireless adaopter is working properly' }))
        }
        if(this.state.accessPoint === 'NOT_VERIFIED'){
          
            this.setState(prevState => ({accessPointSol:!prevState.accessPointSol, accessPointSolution : 'Use your wireless access point or routers administrative GUI to verify network settings for the wireless network service set identifier (SSID) to which your Wi-Fi client is trying to connect.' }))
        }
        else{
            this.setState(prevState => ({accessPointSol:!prevState.accessPointSol, accessPointSolution : 'Your AccessPoint and router settings are proper' }))
        }
        if(this.state.tcpSetting === 'NOT_VERIFIED') {
           
            this.setState(prevState => ({tcpSettingSol:!prevState.tcpSettingSol, tcpSettingSolution : 'Open the network tcpSetting control panel and select your wireless network adapter' }))
        }
        else{
           
            this.setState(prevState => ({tcpSettingSol:!prevState.tcpSettingSol, tcpSettingSolution : 'Your TCP/IP settings are proper' }))
        }
        if(this.state.networkPing === 'NOT_VERIFIED') {
           
            this.setState(prevState => ({networkPingSol:!prevState.networkPingSol, networkPingSolution : 'If pinging your AP or router is successful, then ping any other wired or wireless LAN client that you wish to share files or printers with. If that ping fails, then the destination may be using a firewall to block incoming messages.' }))
        }
        else{
            this.setState(prevState => ({networkPingSol:!prevState.networkPingSol, networkPingSolution : 'Your Network connection is good' }))
        }
    }
    handleIssue = (e) => {
         this.setState({isIssueResolved: e.target.value.toUpperCase()})
    }
    // handleIssueSelection = () => {
    //     if(this.state.isIssueResolved === 'NO'){
    //         this.setState(prevState => ({showMsg:!prevState.showMsg }))
               
    //     }
    // }
    solvedOrNot=(e)=>{

    }
    render(){
        console.log('this.state.accessPointSol',this.state.accessPointSol);
        return(
            <div style={{border:'2px solid black', margin:'10px', padding:'10px'}}>
                <h1>Provide answers for below questions</h1>
                <form  onSubmit={this.handleSubmit}>
                    
                    <h3 style={{ padding:'10px'}}>Select your answers</h3>
                    <div >
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Check WAN and LAN connections</span> 
                        <select value={this.state.cable} onChange={this.updateData_Power} >
                         <option>Select</option>
                        <option>CONNECTED</option>
                        <option>NOT_CONNECTED</option>
                        </select><br/><br/>
                        </label> 
                    </div>
                    <div >
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Verify wireless adapter</span>
                        <select value={this.state.adapters} onChange={this.updateData_Wires} >
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div >
                        <label><span style={{padding:'25px', fontWeight:"bold"}}>Verify AP and router settings</span>
                        <select value={this.state.accessPoint} onChange={this.updateData_Cycling} >
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px', fontWeight:"bold"}}>Verify TCP/IP settings</span>
                        <select value={this.state.tcpSetting} onChange={this.updateData_Connections}>
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    <div>
                        <label><span style={{padding:'20px' , fontWeight:"bold"}}>Verify network connection with Ping</span>
                        <select value={this.state.networkPing} onChange={this.updateData_Outages}>
                        <option>Select</option>
                        <option>VERIFIED</option>
                        <option>NOT_VERIFIED</option>
                        </select><br/><br/>
                        </label>
                    </div>
                    </div>
                    <button className="btn btn-success">Submit</button>
                    
                    
                </form>
                        {this.state.cableConnectionSol &&   <div> 
                            <h3> {this.state.cableConnectionSolution} </h3> 
                        </div>}
                        {this.state.adapterSol &&   <div>
                           <h3>{this.state.adapterSolution}</h3>
                        </div>}
                        {this.state.accessPointSol &&   <div> 
                            <h3>{this.state.accessPointSolution}</h3>
                        </div>}
                        {this.state.tcpSettingSol &&   <div> 
                            <h3>{this.state.tcpSettingSolution}</h3>
                        </div>}
                        {this.state.networkPingSol &&   <div> 
                            <h3>{this.state.networkPingSolution}</h3>
                        </div>}
                        
               {this.state.isSubmitted &&         <div>
                            Is Your issue resolved:<select value={this.state.isIssueResolved} onChange={this.handleIssue}>
                            <option>Select</option>
                            <option>Yes</option>
                            <option>NO</option>
                            </select><br/><br/>
                            <div style={{margin:'10px'}}>
                                {this.state.isIssueResolved === 'YES' ?'Thank you!!':''}
                                {this.state.isIssueResolved === 'NO' ?<CustomerService/>:''}
                            </div>
               </div>}

            </div>
        );
    }
}
export default Comp2;