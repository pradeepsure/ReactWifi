import React, {Component} from 'react'
import {Link, NavLink} from 'react-router-dom'
import AuthenticationService from './AuthenticationService.js'


class HeaderComponent extends Component {
   
    render() {
        const isUserLoggedIn = AuthenticationService.isUserLoggedIn();
        //console.log(isUserLoggedIn);

        return (
            <header>
                <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    <div><a href="" className="navbar-brand">Wi-Fi-Troubleshoot</a></div>
                    <ul className="navbar-nav">
                        {isUserLoggedIn && <li><NavLink className="nav-link" to="/home"  activeClassName="selected"  activeStyle={{
    fontWeight: "bold",
    color: "red"
  }}>Home</NavLink></li>}
                        {isUserLoggedIn && <li><NavLink className="nav-link" to="/issue1" activeClassName="selected"  activeStyle={{
    fontWeight: "bold",
    color: "red"
  }}>Network-Issue</NavLink></li>}
                        {isUserLoggedIn && <li><NavLink className="nav-link" to="/issue2" activeClassName="selected"  activeStyle={{
    fontWeight: "bold",
    color: "red"
  }}>Lan-Issue</NavLink></li>}
                        {isUserLoggedIn && <li><NavLink className="nav-link" to="/issue3" activeClassName="selected"  activeStyle={{
    fontWeight: "bold",
    color: "red"
  }}>Router-Issue</NavLink></li>}
                    </ul>
                    <ul className="navbar-nav navbar-collapse justify-content-end">
                        {!isUserLoggedIn && <li><Link className="nav-link" to="/login">Login</Link></li>}
                        {isUserLoggedIn && <li><Link className="nav-link" to="/logout" onClick={AuthenticationService.logout}>Logout</Link></li>}
                    </ul>
                </nav>
            </header>
        )
    }
}
// <NavLink
//   to="/events/123"
//   isActive={oddEvent}
// >Event 123</NavLink>

export default HeaderComponent